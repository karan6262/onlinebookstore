/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package book;
import java.sql.*;
/**
 *
 * @author karan
 */
public class Books {

        String URL = "jdbc:mysql://localhost:3306/OnlineBookStore";
        String USERNAME = "root";
        String PASSWORD = "root";

        Connection con = null;
        PreparedStatement selectBooks = null;

        public Books() {
            try {
                con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public ResultSet getBook(String id) {
            ResultSet rs = null;
            try {
                selectBooks = con.prepareStatement("SELECT * FROM BOOKS where id = " + id);
                rs = selectBooks.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rs;

        }

        public ResultSet getBooks() {
            ResultSet rs = null;
            try {
                selectBooks = con.prepareStatement("SELECT * FROM BOOKS ORDER BY RAND() LIMIT 3");
                rs = selectBooks.executeQuery();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return rs;
        }
        
        
        public ResultSet getBooksById(String ids) {
            
            ResultSet rs = null;
            try {
                if(ids.equals("")){
                    ids = "0";
                }
                selectBooks = con.prepareStatement("SELECT * FROM BOOKS  WHERE id in ("+ids+")");
                rs = selectBooks.executeQuery();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return rs;
        }
    }

package book;
import java.sql.*;
public class authors {

    String URL = "jdbc:mysql://localhost:3306/OnlineBookStore";
    String USERNAME = "root";
    String PASSWORD = "root";

    Connection con = null;
    PreparedStatement selectAuth = null;
    ResultSet rs = null;

    public authors() {
        try {
            con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            selectAuth = con.prepareStatement("SELECT distinct  author FROM BOOKS order by author");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet getAuths() {
        try {
            rs = selectAuth.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;

    }

    public ResultSet getAuthbyname(String name) {
        ResultSet rs = null;
        try {
            selectAuth = con.prepareStatement("select * from author where auth_name ='" + name + "'");
            rs = selectAuth.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public ResultSet getAuthBooks(String name) {
        ResultSet rs = null;
        try {
            PreparedStatement st = con.prepareStatement("select * from books where author='" + name + "'");
            rs = st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }
}
